import SignUp1 from './SignUp1.jsx';

export default function SignUp() {
    
  return (
    <SignUp1 />
  )
}
