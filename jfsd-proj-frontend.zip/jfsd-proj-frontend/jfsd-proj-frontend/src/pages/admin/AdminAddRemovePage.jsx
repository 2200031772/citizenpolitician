import { useNavigate } from 'react-router-dom';
import styles from './AdminAddRemovePage.module.css';
import userPic from './imagess/user.png';

export default function AdminAddRemovePage() {

  const navigate = useNavigate()

  function handleAddPolitician() {
      navigate('/admin/addPolitician');
  }

  return (
    <div className={styles.container}>
      <h1 className={styles.title}>Admin Add/Remove Options</h1>
      <div className={styles.cardContainer}>
        <div className={styles.card}>
          <img src={userPic} alt="User" className={styles.cardImage} />
          <h2 className={styles.cardTitle}>Add User</h2>
          <p className={styles.cardDescription}>Manage and add new users to the system.</p>
          <button className={styles.cardButton}>Add User</button>
        </div>
        <div className={styles.card}>
          <img src={userPic} alt="User" className={styles.cardImage} />
          <h2 className={styles.cardTitle}>Add Politician</h2>
          <p className={styles.cardDescription}>Add new politicians and manage their details.</p>
          <button className={styles.cardButton} onClick={handleAddPolitician}>Add Politician</button>
        </div>
        <div className={styles.card}>
          <img src={userPic} alt="User" className={styles.cardImage} />
          <h2 className={styles.cardTitle}>Add Admin</h2>
          <p className={styles.cardDescription}>Add new admins to the system.</p>
          <button className={styles.cardButton}>Add Admin</button>
        </div>
      </div>
    </div>
  );
}

