
export default function PolitciansApplications() {
  return (
    <div>
      <h1>Welcome to Applications</h1>
    </div>
  )
}
