package com.platform.service;

import com.platform.model.Discussion;

public interface DiscussionSerice {

	public String addDiscussion(Discussion D);
	
}
