package com.platform.service;

import com.platform.model.FeedBack;

public interface FeedbackService {

	public String addFeedback(FeedBack FB);
	
}
